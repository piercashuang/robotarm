using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO.Ports;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections;
using System.Threading;
using GJC.Helper;
using PimDeWitte.UnityMainThreadDispatcher;
using System.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Linq;

namespace XP.TableModel.Test
{
public class comconnect : MonoBehaviour
{
    public Button upcamera;
    public Button leftcamera;
    public Button rightcamera;
    public Button downcamera;

    [SerializeField] InputField m3i2input;
    public Button m3i2sendcmd;
    //public Button testrotate;
    public static string _DefaultTxtPath = ""; // 修改为你的配置文件路径
    public static string m3i1value = "testm3i1";
    public static string m3i1_Ivalue = "";
    public static string m3i1_Ovalue = "";
    public Text posx,posy,posz,posa,posb,posc;

    private bool running = false;

    public GameObject viewverify;
    
    string rownum = "";
    string closeiorownum = "";
    public Table _Table;
    public Table _Tablem2i4;
    private string accumulatedData = "";
    private TcpClient tcpClient;
    private string previousData = "";
    private NetworkStream networkStream;
    public List<Slider> sliders = new List<Slider>();
    public List<Button> btns = new List<Button>();
    public List<Button> btnscoms = new List<Button>();
    [SerializeField] public InputField field;
    [SerializeField] public InputField fieldx;
    [SerializeField] public InputField fieldy;
    [SerializeField] public InputField fieldz;

    
    public Button closeverifywin;
    public Button verifyendcom;
    public Button cancelendcom;

    private int speed = 1;
    public GameObject[] imgspeeds;
    public Button imgspeedadd;
    public Button imgspeedminus;

    private int precision = 1;
    public GameObject[] imgprecisions;
    public Button imgprecisionadd;
    public Button imgprecisionminus;

    public Transform[] bones;
    public Button btncom,_openio,closeio;
    public Button btnfresh;
    // public Button btnoffbrake;
    private string sliderName;
    public Dropdown dropdownMenu;
    public Dropdown drp3Component;
    public Button btnFreshComponent;
    public Button btngetconfig;
    private bool _continue = true;

    public string portName = "COM5"; //串口名
    private int baudRate = 1000000; //波特率 0是1000000，1是512000，2是230400，3是115200，4是9600
    public Parity parity = Parity.None; //效验位
    public int dataBits = 8; //数据位
    public StopBits stopBits = StopBits.One; //停止位
    SerialPort sp = null;
    private Thread readThread;


    public Button btnconnect;
    public Button btngcode;
    [SerializeField] public InputField inputaddr;
    [SerializeField] public InputField inputport;
                        
    [SerializeField] public InputField inputovertime;
    [SerializeField] public InputField inputBaudRateComponent;

    [SerializeField] private float value;
    [SerializeField] private float value1;
    [SerializeField] private float value2;
    [SerializeField] private float value3;
    [SerializeField] public InputField inputgcode;
    private Action action;


    public Transform originBone0;
    public Transform originBone1;
    public Transform originBone2;
    public Transform originBone3;

    private Quaternion oriAngle0;
    private Quaternion oriAngle1;
    private Quaternion oriAngle2;
    private Quaternion oriAngle3;

    private float bone0_x_rotation = 103;
    private float bone1_z_rotation = -4;
    private float bone2_z_rotation = -66;
    private float bone4_x_rotation = 0;
    private float bone4_z_rotation = -13;
    


    private void Awake()
{
    ThreadCrossHelper.Instance.init();

    // 获取所有带有 "comconnect" 标签的游戏对象并转换为列表
    List<GameObject> views = GameObject.FindGameObjectsWithTag("comconfig").ToList();

    // 初始化组件变量
    inputBaudRateComponent = null;
    btnFreshComponent = null;
    drp3Component = null;
    inputovertime = null;

    // 遍历列表中的每个游戏对象
    foreach (GameObject view in views)
    {
        // 根据游戏对象的名称获取相应组件
        switch (view.name)
        {
            case "inputbaudrate":
                inputBaudRateComponent = view.GetComponent<InputField>();
                break;

            case "inputovertime":
                inputovertime = view.GetComponent<InputField>();
                break;

            case "btnfresh":
                btnFreshComponent = view.GetComponent<Button>();
                break;

            case "btngetconfig":
                btngetconfig = view.GetComponent<Button>();
                break;


            case "drp3":
                drp3Component = view.GetComponent<Dropdown>();
                break;


                

            // 添加其他可能的组件...

            default:
                // 如果有其他游戏对象，可以在此添加处理逻辑
                break;
        }
    }
    InitDropdownMenu();
}


    private void testrotateClick(){

        bones[0].localRotation = Quaternion.Euler(1F * new Vector3(bone0_x_rotation-50, -90, -90));
        bones[1].localRotation = Quaternion.Euler(1F * new Vector3(0, -13, 20+bone1_z_rotation ));
        bones[2].localRotation = Quaternion.Euler(1F * new Vector3(0, 0, -20+bone2_z_rotation));
        bones[3].localRotation = Quaternion.Euler(1F * new Vector3(bone4_x_rotation+20, -0, bone4_z_rotation+60));
        // bones[0].localRotation = Quaternion.Euler(0.5F * new Vector3(0, 360, 0)); //底座X轴动 (骨骼
        // bones[1].localRotation = Quaternion.Euler(0.6F  * new Vector3(360, 0, 0));
        // bones[2].localRotation = Quaternion.Euler(0.4F * new Vector3(360, 0, 0));
        // bones[3].localRotation = Quaternion.Euler(0.2F * new Vector3(360, 0, 0)); //动Z轴是前后旋转, 或者XY一起动是横向动 (骨骼004)


    }
    private void Start()
    {

            for(int i = 0 ; i <5 ; i++){
        imgprecisions[i].SetActive(false);
    }
    imgprecisions[precision-1].SetActive(true);

        for(int i = 0 ; i <5 ; i++){
        imgspeeds[i].SetActive(false);
    }
    imgspeeds[speed-1].SetActive(true);

    

        oriAngle0 = originBone0.rotation;
        oriAngle1 = originBone1.rotation;
        oriAngle2 = originBone2.rotation;
        oriAngle3 = originBone3.rotation;

        // _DefaultTxtPath=Application.persistentDataPath+"ioconfig.txt";
        // 获取Dropdown组件
        // dropdownMenu = this.transform.GetChild(2).GetChild(4).GetComponent<Dropdown>();

        // 添加下拉菜单选项
        // AddDropdownOptions();

        viewverify.SetActive(false);

        //  transform.Find("")  只能找子物体 不能找子子物体
        Init();
        
            _openio.onClick.AddListener(() =>
            {
                openio_printrow();
            });


                closeio.onClick.AddListener(() =>
                {
                    closeio_printrow();
                });





    


        // sliders[0].onValueChanged.AddListener((f) => { value = f; });
        // sliders[1].onValueChanged.AddListener((f) => { value1 = f; });
        // sliders[2].onValueChanged.AddListener((f) => { value2 = f; });
        // sliders[3].onValueChanged.AddListener((f) => { value3 = f; });
        // dropdownMenu.onValueChanged.AddListener((f) => { OnDropdownValueChanged(); });


        // btns[0].onClick.AddListener(() => { print(fieldx.text + fieldy.text + fieldz.text); });

        // 连接串口
        btncom.onClick.AddListener(() => { ConnectButtonClick(); });


        //确定断开串口
        verifyendcom.onClick.AddListener(() => { verifyendcomClick(); });


        cancelendcom.onClick.AddListener(()=> { cancelendcomClick(); });
        
        // testrotate.onClick.AddListener(()=> { testrotateClick(); });

        closeverifywin.onClick.AddListener(()=> { closeverifywinonClick(); });

        imgspeedadd.onClick.AddListener(()=> { imgspeedaddonClick(); });

        imgspeedminus.onClick.AddListener(()=> { imgspeedminusonClick(); });

        imgprecisionadd.onClick.AddListener(()=> { imgprecisionaddonClick(); });

        imgprecisionminus.onClick.AddListener(()=> { imgprecisionminusonClick(); });
        
        
        // //刷新
        btnFreshComponent.onClick.AddListener(() => { RefreshSerialPorts(); });

        // btnconnect.onClick.AddListener(() => { ConnectTcp(); });

        // Debug.Log("btngcode: " + (btngcode != null ? "Not null" : "Null"));
        // Debug.Log("inputgcode: " + (inputgcode != null ? "Not null" : "Null"));

        // btngcode.onClick.AddListener(() => { SendSerialData(inputgcode.text); });
        btngetconfig.onClick.AddListener(() => { SendDollar(); });
        // btnoffbrake.onClick.AddListener(() => { offbrake(); });


        m3i2sendcmd.onClick.AddListener(() => { m3i2sendcmdonlick(); });
    }

    public void m3i2sendcmdonlick(){
        if (sp != null && sp.IsOpen)
        {
            //  sp.Write("\r\n"+"m12.16"+"\r\n");
            sp.Write("\r\n"+m3i2input.text+"\r\n");

            // sp.Write("\r\n"+"m12.16"+"\r\n");
            // sp.Write("\r\n"+"G00X0.000Y0.000Z30.000A20.000B10.000C0.000"+"\r\n");
            
            print(m3i2input.text);
            
  
        }
    }
    public void verifyendcomClick(){
        print("关闭系统");
        

                if (sp != null && sp.IsOpen)
        {
            sp.Close();
            viewverify.SetActive(false);
            
  
        }

        // if(sendQuestion != null){
        //     sendQuestion.Close();
        // }

        //         if(readDollar != null){
        //     readDollar.Close();
        // }



    }

    private void imgprecisionaddonClick(){
                if(precision <= 4){
            precision += 1;
        }
        print("precision is: "+precision);
    for(int i = 0 ; i <5 ; i++){
        imgprecisions[i].SetActive(false);
    }
    imgprecisions[precision-1].SetActive(true);

    }

    private void imgprecisionminusonClick(){
        if(precision >= 2){
            precision -= 1;
        }
        print("precision is: "+precision);
    for(int i = 0 ; i <5 ; i++){
        imgprecisions[i].SetActive(false);
    }
    imgprecisions[precision-1].SetActive(true);
    }




    private void imgspeedaddonClick(){
        if(speed <= 4){
            speed += 1;
        }
        print("speed is: "+speed);
    for(int i = 0 ; i <5 ; i++){
        imgspeeds[i].SetActive(false);
    }
    imgspeeds[speed-1].SetActive(true);
    }


        private void imgspeedminusonClick(){
        if(speed >= 2){
            speed -= 1;
        }
        print("speed is: "+speed);
    for(int i = 0 ; i <5 ; i++){
        imgspeeds[i].SetActive(false);
    }
    imgspeeds[speed-1].SetActive(true);
    }



    private void closeverifywinonClick(){
        viewverify.SetActive(false);
    }

    private void Init()

    {
        
        System.IO.Ports.SerialPort sp = new System.IO.Ports.SerialPort();
        // string[] ports = SerialPort.GetPortNames();
        // print(ports);
        // if (ports.Length > 0)
        // {
        //     Debug.Log("Available Serial Ports:");

        //     foreach (string port in ports)
        //     {
        //         Debug.Log(port);
        //     }
        // }
        // else
        // {
        //     Debug.Log("No serial ports available.");
        // }

        print(sp);
        // var sliderZone = this.transform.GetChild(0);
        // var btnZone = this.transform.GetChild(1);
        // var tcpZone = this.transform.GetChild(4);
        // btnoffbrake = this.transform.GetChild(5).GetComponent<Button>();  //comconnect
        // fieldx = this.transform.GetChild(1).GetChild(1).GetComponent<InputField>();
        // fieldy = this.transform.GetChild(1).GetChild(2).GetComponent<InputField>();
        // fieldz = this.transform.GetChild(1).GetChild(3).GetComponent<InputField>();
        // btncom = this.transform.GetChild(5).GetComponent<Button>();
        // btnfresh = this.transform.GetChild(2).GetChild(5).GetComponent<Button>();
        // inputaddr = this.transform.GetChild(4).GetChild(1).GetComponent<InputField>();
        // inputport = this.transform.GetChild(4).GetChild(2).GetComponent<InputField>();
        // btnconnect = this.transform.GetChild(4).GetChild(0).GetComponent<Button>();

        // btngcode = this.transform.GetChild(3).GetChild(0).GetComponent<Button>();
        // inputgcode = this.transform.GetChild(3).GetChild(1).GetComponent<InputField>();
        // for (int i = 0; i < sliderZone.childCount; i++)
        // {
        //     var child = sliderZone.GetChild(i); //slider第一个子物体 
        //     sliders.Add(child.GetComponent<Slider>());
        // }

        // for (int i = 0; i < btnZone.childCount; i++)
        // {
        //     var child = btnZone.GetChild(i);
        //     btns.Add(child.GetComponent<Button>());
        // }
    }

    private void cancelendcomClick(){
        viewverify.SetActive(false);
    }

    private void InitDropdownMenu()
    {
        // Get the Dropdown component
        // dropdownMenu = this.transform.GetChild(2).GetChild(4).GetComponent<Dropdown>();

        // Add listener to handle dropdown value changes
        // dropdownMenu.onValueChanged.AddListener(OnDropdownValueChanged);

        // Refresh serial ports when the script starts
        RefreshSerialPorts();
    }

    private void OnDropdownValueChanged()
    {
        print("Selected Serial Port: " + dropdownMenu.GetComponent<Dropdown>().value);

        // You can use the selected port as needed, e.g., set ComPort variable.
    }

    private void RefreshSerialPorts()
    {
        try
        {
            // 创建临时的 SerialPort 对象以检索端口名称
            System.IO.Ports.SerialPort sp = new System.IO.Ports.SerialPort();
            print(sp);

            // 获取端口名称
            string[] str = System.IO.Ports.SerialPort.GetPortNames();
            print(str);
            if (str.Length > 0)
            {
                Debug.Log("Available Serial Ports:");

                foreach (string port in str)
                {
                    Debug.Log(port);
                }
            }

            // 将端口名称打印到控制台
            // foreach (string port in str)
            // {
            //     print(port);
            // }

            // 清除并更新下拉菜单选项
            List<string> options = new List<string>(str);
            drp3Component.ClearOptions();
            drp3Component.AddOptions(options);
        }
        catch (Exception e)
        {
            Debug.LogError("刷新串口时出现错误：" + e.Message);
        }
    }



    private void config(){

    }

    private void ConnectButtonClick()

    {

            if (sp != null && sp.IsOpen)
            {
                
                viewverify.SetActive(true);

                // sp.Close();
            }else{
                



            print(inputovertime.text);
            print(inputBaudRateComponent.text);

            //find the selected index
            int menuIndex = drp3Component.GetComponent<Dropdown>().value;

            //find all options available within the dropdown menu
            List<Dropdown.OptionData> menuOptions = drp3Component.GetComponent<Dropdown>().options;

            //get the string value of the selected index
            string value = menuOptions[menuIndex].text;
            print(value);

            portName = value;
            print("public baudrate is :" + inputBaudRateComponent.text);
            
            sp = new SerialPort(portName, Int32.Parse(inputBaudRateComponent.text), parity, dataBits, stopBits);
            sp.ReadTimeout = Int32.Parse(inputovertime.text)*1000;


            sp.Open();
            print("connect com");
            // StartCoroutine(SendQuestionCoroutine());

                // 在主线程中执行的代码
                // 操作 Unity 对象等
                Thread sendQuestion = new Thread(new ThreadStart(SendQuestionCoroutine));
                //_continue = true;
                sendQuestion.Start();





            // print("loopsend");
            ThreadCrossHelper.Instance.AddMainThread(() =>
            {
                // 在主线程中执行的代码
                // 操作 Unity 对象等
                Thread readThread = new Thread(new ThreadStart(Read));
                //_continue = true;
                readThread.Start();
            });

                
            }

    }


    // void AddDropdownOptions()
    // {
    //     // 创建一个选项列表
    //     List<string> options = new List<string>();
    //     options.Add("Option 1");
    //     options.Add("Option 2");
    //     options.Add("Option 3");

    //     // 清空原有的选项
    //     dropdownMenu.ClearOptions();

    //     // 添加新的选项
    //     dropdownMenu.AddOptions(options);
    // }

    public void SendQuestion()
    {
        sp.Write("?");
    }


            private void openio_printrow()
        {
            
            // 将选中单元格的显示数据设置为输入框的文本
            foreach (var item in _Tablem2i4._CurrentSelectedCellDatas)
            {
                print(item._Row);
                            if (item._Row >7){
                rownum = (item._Row-7).ToString();
                            if(rownum.Length == 1){
                rownum= "0"+rownum;
            }

            rownum = "M12." + rownum;
            print("send openio cmd: "+ rownum);
            sp.Write("\r\n"+rownum+"\r\n");

            }
            }

            // updateio();
        }


                    private void closeio_printrow()
        {
            
            // 将选中单元格的显示数据设置为输入框的文本
            foreach (var item in _Tablem2i4._CurrentSelectedCellDatas)
            {
                print(item._Row);
                            if (item._Row >7){
                closeiorownum = (item._Row-7).ToString();
                            if(closeiorownum.Length == 1){
                closeiorownum= "0"+closeiorownum;
            }

            closeiorownum = "M11." + closeiorownum;
            print("send closeio cmd: "+ closeiorownum);
            sp.Write("\r\n"+closeiorownum+"\r\n");

            }
            }
        }






    

    public void SendDollar()
    {


                ThreadCrossHelper.Instance.AddMainThread(() =>
        {
            // 在主线程中执行的代码
            // 操作 Unity 对象等
            Thread readDollar = new Thread(new ThreadStart(readdollar));
            //_continue = true;
            readDollar.Start();
        });


        // 在要发送的数据末尾添加换行符
        string dataWithNewLine = "$$" + "\r\n";
        
        // 发送带有换行符的数据
        sp.Write(dataWithNewLine);

        print(dataWithNewLine);


    }


        public void readdollar()
    {
        byte[] buffer = new byte[8192]; // 或者使用更大的大小


        print("before while");

       while (true){

            if (sp != null && sp.IsOpen)
            {
                try
                {
                    int bytesRead = sp.Read(buffer, 0, buffer.Length);

                    // 将读取到的数据拼接到 accumulatedData 变量
                    accumulatedData += Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    print(accumulatedData);

                    if(string.IsNullOrEmpty(accumulatedData)){
                        
                        break;
                    }


                }
                catch (TimeoutException ex)
                {
                    UnityEngine.Debug.LogError($"TimeoutException: {ex.Message}");
                }
            }
            else
            {
                UnityEngine.Debug.LogError("Serial port is not open!");
            }
            // Thread.Sleep(1000);
        }
    }
    

    public void SendSerialData(string data)
    {
        // 在要发送的数据末尾添加换行符
        string dataWithNewLine = data + "\r\n";
        sp.Write("\r\n");
        // 发送带有换行符的数据
        sp.Write(dataWithNewLine);

        print(dataWithNewLine);
    }

    public void offbrake()
    {
        sp.Write("\r\n" + "m12.16" + "\r\n");
    }


    private void SendQuestionCoroutine()
    {
        while (true)
        {
            // 发送问号
            SendQuestion();
            Thread.Sleep(1000);

        }
    }


    public void OpenSerialPort()
    {
        // // Initialise the serial port
        // SerialPort = new SerialPort(ComPort, BaudRate, Parity, DataBits, StopBits);

        // SerialPort.ReadTimeout = ReadTimeout;
        // SerialPort.WriteTimeout = WriteTimeout;

        // SerialPort.DtrEnable = DtrEnable;
        // SerialPort.RtsEnable = RtsEnable;

        // // Open the serial port
        // SerialPort.Open();
    }


    public void Read()
    {
        byte[] buffer = new byte[5120]; // 或者使用更大的大小


        print("before while");

        while (true)
        {
            if (sp != null && sp.IsOpen)
            {
                try
                {
                    int bytesRead = sp.Read(buffer, 0, buffer.Length);

                    // 将读取到的数据拼接到 accumulatedData 变量
                    accumulatedData += Encoding.ASCII.GetString(buffer, 0, bytesRead);

                    // 检查是否收到了字符 ">"
                    int endIndex = accumulatedData.IndexOf(">");
                    if (endIndex != -1)
                    {
                        // 截取 ">" 之前的数据作为完整消息
                        string completeMessage = accumulatedData.Substring(0, endIndex);

                        // 处理完整的消息
                        ProcessReceivedData(completeMessage);

                        UpdateIO(completeMessage);
                        // 清空 accumulatedData，准备接收下一条消息
                        accumulatedData = "";

                        // 如果 ">" 后还有数据，继续处理
                        if (endIndex + 1 < accumulatedData.Length)
                        {
                            accumulatedData = accumulatedData.Substring(endIndex + 1);
                        }
                    }


                    // Thread.Sleep(1000);
                    // int bytes = sp.Read(buffer, 0, buffer.Length);
                    // print(bytes);
                    // if (bytes == 0)
                    // {
                    //     continue;
                    // }
                    // else
                    // {   
                    //     string receivedData = Encoding.ASCII.GetString(buffer, 0, bytes);
                    //     print(receivedData);
                    //     // 检查字符串中是否包含"ABSPos:"
                    //     // 检查字符串中是否包含"ABSPos:"
                    //     if (receivedData.Length > 70)
                    //     {   
                    //         //print("start find");
                    //         // 找到"ABSPos:"的位置
                    //         int absPosIndex = receivedData.IndexOf("ABSPos:");
                    //         print(absPosIndex);
                    //         // 提取"ABSPos:"后的子字符串
                    //         string remainingString = receivedData.Substring(absPosIndex + "ABSPos:".Length);
                    //         print(remainingString);
                    //         // 检查字符串中是否包含" | "，表示结尾
                    //         int endIndex = remainingString.IndexOf("|");

                    //         // 提取满足条件的部分
                    //         string absPosData = remainingString.Substring(0, endIndex);
                    //         print(endIndex);
                    //         // 输出结果
                    //         print("ABSPos Data: " + absPosData);

                    //         // 将 absPosData 根据逗号分隔成字符串数组
                    //         string[] values = absPosData.Split(',');

                    //         if (values.Length == 6)
                    //         {
                    //             // 将字符串数组的元素解析为浮点数
                    //             float x = float.Parse(values[0]);
                    //             float y = float.Parse(values[1]);
                    //             float z = float.Parse(values[2]);
                    //             float a = float.Parse(values[3]);
                    //             float b = float.Parse(values[4]);
                    //             float c = float.Parse(values[5]);

                    //             // 使用 UpdateRotation 方法更新物体的旋转


                    //                 UnityMainThreadDispatcher.Instance().Enqueue(() =>
                    //                 {
                    //                     // 执行需要在主线程中完成的操作
                    //                     Debug.Log("This is executed on the main thread.");
                    //                     UpdateRotation(x, y, z, a);
                    //                 });


                    //         }
                    //         else
                    //         {
                    //             Debug.LogError("Invalid number of values in ABSPos data.");
                    //         }

                    //     }else{
                    //         print("less than 70");
                    //     }
                    //     // string strbytes = Encoding.Default.GetString(buffer, 0, bytes);

                    //     // // 检查接收到的数据是否与先前的数据不同
                    //     // if (strbytes != previousData)
                    //     // {
                    //     //     previousData = strbytes;
                    //     //     action = () => { ReceiveMsg(strbytes); };
                    //     // }
                    // }
                }
                catch (TimeoutException ex)
                {
                    UnityEngine.Debug.LogError($"TimeoutException: {ex.Message}");
                }
            }
            else
            {
                UnityEngine.Debug.LogError("Serial port is not open!");
            }
            // Thread.Sleep(1000);
        }
    }


    static void UpdateIO(string input)
    {
        // 查找 "Pn:O" 的位置
        int pnIndex = input.IndexOf("Pn:O");

        if (pnIndex != -1)
        {
            // 去掉该位置之前的字符串
            input = input.Substring(pnIndex + "Pn:O".Length);

            // 找到更新后字符串中的第一个 "|"
            int firstPipeIndex = input.IndexOf("|");

            if (firstPipeIndex != -1)
            {
                // 截取 "I" 后面的字符串
                string modifiedString = input.Substring(0, firstPipeIndex);

                // 去掉剩下字符串里的 "O" 和 "I"
                modifiedString = modifiedString.Replace("Pn:O", "").Replace("I", "");

                // 逗号分隔存入两个变量
                string[] values = modifiedString.Split(',');

                if (values.Length >= 2)
                {
                    string variable1 = values[0];
                    string variable2 = values[1];
                    m3i1_Ivalue = variable1;
                    m3i1_Ovalue = variable2;
                    // 在这里进行相应的处理
                    print("Variable 1: " + variable1);
                    print("Variable 2: " + variable2);
                }
            }
        }
    }



    private void ProcessReceivedData(string receivedData)
    {
        print(receivedData);

        // 检查是否包含MPos
        if (receivedData.Length > 70 && receivedData.Contains("MPos:"))
        {
            // if(receivedData.Contains("Pn:")){
            //     _Table._SetCellData(2,4,"testagain");
            // }

            
            int absPosIndex = receivedData.IndexOf("MPos:");
            string remainingString = receivedData.Substring(absPosIndex + "MPos:".Length);
            int endIndex = remainingString.IndexOf("|");

            // 提取满足条件的部分
            string absPosData = remainingString.Substring(0, endIndex);
            print("MPos Data: " + absPosData);

            // 将 absPosData 根据逗号分隔成字符串数组
            string[] values = absPosData.Split(',');

            if (values.Length == 6)
            {
                // 将字符串数组的元素解析为浮点数
                float x = float.Parse(values[0]);
                float y = float.Parse(values[1]);
                float z = float.Parse(values[2]);
                float a = float.Parse(values[3]);
                float b = float.Parse(values[4]);
                float c = float.Parse(values[5]);







                // 使用 UpdateRotation 方法更新物体的旋转
                UnityMainThreadDispatcher.Instance().Enqueue(() =>
                {
                bones[0].localRotation = Quaternion.Euler(1F * new Vector3(bone0_x_rotation+c, -90, -90)); //对应c
                bones[1].localRotation = Quaternion.Euler(1F * new Vector3(0, -13, b+bone1_z_rotation )); //对应b
                bones[2].localRotation = Quaternion.Euler(1F * new Vector3(0, 0, a+bone2_z_rotation)); //对应a
                bones[3].localRotation = Quaternion.Euler(1F * new Vector3(bone4_x_rotation+y, -0, bone4_z_rotation+z)); //横着的是y 竖着的是z


                posx.text = "X"+x.ToString() + " Y"+y.ToString() + " Z"+z.ToString()+" A"+a.ToString()+" B"+b.ToString()+" C"+c.ToString();
                print("底边条值为: "+posx.text);


                    // 执行需要在主线程中完成的操作
                    // Debug.Log("This is executed on the main thread.");
                    // UpdateRotation(x, y, z, a);
                });
            }
            else
            {
                Debug.LogError("Invalid number of values in MPos data.");
            }
        }
        else
        {
            print("less than 70 or does not contain MPos");
        }
    }


    private void ReceiveMsg(string obj)
    {
        // Debug.Log(obj);
        // GameObject prefab = Resources.Load<GameObject>("字体");
        // var textShow = GameObject.Instantiate(prefab).GetComponent<TextShow>();
        // textShow.showContent = obj;
        // textShow.Init();
    }


    private void ConnectTcp()
    {
        try
        {
            // 创建 TcpClient 对象并连接到服务器
            tcpClient = new TcpClient();
            tcpClient.Connect(new IPAddress(new byte[] { 127, 0, 0, 1 }), 6069);

            // 如果连接成功，启动一个协程来处理数据传输
            StartCoroutine(HandleTcpConnection());
        }
        catch (Exception ex)
        {
            Debug.LogError("Error connecting to server: " + ex.Message);
        }
    }

    private IEnumerator HandleTcpConnection()
    {
        // 获取 NetworkStream 对象
        networkStream = tcpClient.GetStream();

        // 发送数据的例子
        string messageToSend = "A,0,0,1.57,0,0,0,4";
        byte[] dataToSend = Encoding.UTF8.GetBytes(messageToSend);
        networkStream.Write(dataToSend, 0, dataToSend.Length);

        // // 接收数据的例子
        // byte[] dataReceived = new byte[256];
        // int bytesRead = networkStream.Read(dataReceived, 0, dataReceived.Length);
        // string receivedMessage = Encoding.UTF8.GetString(dataReceived, 0, bytesRead);
        // Debug.Log("Received message from server: " + receivedMessage);

        // 关闭连接
        tcpClient.Close();
        return null;
    }


    // 在程序结束时关闭 TCP 连接
    private void OnDestroy()
    {
        if (tcpClient != null)
        {
            tcpClient.Close();
        }
    }

    private void OnApplicationQuit()
    {
        if (sp != null && sp.IsOpen)
        {
            sp.Close();
            // readDollar.Close();
            
        }

        // Add any other cleanup code as needed
    }


    //     private void ProcessAccumulatedData()
    // {
    //     const string ABSPosMarker = "ABSPos:";
    //     int absPosIndex = accumulatedData.IndexOf(ABSPosMarker);

    //     while (absPosIndex != -1)
    //     {
    //         // 找到了 ABSPos 的位置
    //         int pipeIndex = accumulatedData.IndexOf("|", absPosIndex);

    //         if (pipeIndex != -1)
    //         {
    //             // 找到了 | 的位置
    //             string messageToProcess = accumulatedData.Substring(absPosIndex, pipeIndex - absPosIndex + 1);

    //             // 处理完整的消息
    //             ProcessReceivedData(messageToProcess);

    //             // 从 accumulatedData 中移除已处理的消息
    //             accumulatedData = accumulatedData.Substring(pipeIndex + 1);
    //         }
    //         else
    //         {
    //             // 如果没有找到 |，表示消息不完整，跳出循环等待下一次读取
    //             break;
    //         }

    //         // 继续查找下一个 ABSPos
    //         absPosIndex = accumulatedData.IndexOf(ABSPosMarker);
    //     }
    // }


    // 更新物体的旋转方法
    private void UpdateRotation(float rotationValue, float rotationValue1, float rotationValue2, float rotationValue3)
    {
        print("调用更新旋转函数");
        bones[0].localRotation = Quaternion.Euler(rotationValue * new Vector3(0, 360, 0));
        bones[1].localRotation = Quaternion.Euler(0.6F * rotationValue1 * new Vector3(360, 0, 0));
        bones[2].localRotation = Quaternion.Euler(0.4F * rotationValue2 * new Vector3(360, 0, 0));
        bones[3].localRotation = Quaternion.Euler(0.2F * rotationValue3 * new Vector3(360, 0, 0));
    }
}
}